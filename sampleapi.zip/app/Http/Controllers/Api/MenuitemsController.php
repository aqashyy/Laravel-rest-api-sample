<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\MenuResource;
use App\Models\MenuItem;
use Illuminate\Http\Request;

class MenuitemsController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $menuCategoryId = '1';
        $menuItems = MenuItem::where('type', $menuCategoryId)
        ->where('state', '1')
        ->orderBy('menuorderid', 'ASC')
        ->get(['id', 'title', 'alias','linkaddress','target','viewtype','type','parent_id','menuorderid']);

    // dd($menuItems);

        if ($menuItems) {
            $JsonmenuItems = [];

            // First, we process all the menu items to get top-level items (parent_id = 0)
            foreach ($menuItems as $menu) {
                // Only add top-level menus (those with parent_id = 0)
                if ($menu->parent_id == '0') {
                    $JsonmenuItems[] = [
                        'id' => $menu->id,
                        'title' => $menu->title,
                        'alias' => $menu->alias,
                        'linkaddress' => $menu->linkaddress,
                        'target' => $menu->target,
                        'viewtype' => $menu->viewtype,
                        'type' => $menu->type,
                        'parent_id' => $menu->parent_id,
                        'menuorderid' => $menu->menuorderid,
                    ];
                }
            }

            // Now, let's populate the submenus and subsubmenus for each parent menu
            foreach ($JsonmenuItems as &$parentMenu) {
                $submenus = [];

                foreach ($menuItems as $submenu) {
                    // Check if the current item is a child of the current parent menu
                    if ($submenu->parent_id == $parentMenu['id']) {
                        $submenus[] = [
                            'id' => $submenu->id,
                            'title' => $submenu->title,
                            'alias' => $submenu->alias,
                            'linkaddress' => $submenu->linkaddress,
                            'target' => $submenu->target,
                            'viewtype' => $submenu->viewtype,
                            'type' => $submenu->type,
                            'parent_id' => $submenu->parent_id,
                            'menuorderid' => $submenu->menuorderid,
                        ];
                    }
                }

                // Assign the found submenus to the parent menu's 'submenu' key and order them by `menuorderid`
                if (!empty($submenus)) {
                    $parentMenu['submenu'] = $submenus;
                    usort($parentMenu['submenu'], function ($a, $b) {
                        return $a['menuorderid'] - $b['menuorderid'];
                    });

                    // Recursively populate subsubmenus
                    foreach ($parentMenu['submenu'] as &$submenu) {
                        $subsubmenus = [];
                        foreach ($menuItems as $subsubmenu) {
                            if ($subsubmenu->parent_id == $submenu['id']) {
                                $subsubmenus[] = [
                                    'id' => $subsubmenu->id,
                                    'title' => $subsubmenu->title,
                                    'alias' => $subsubmenu->alias,
                                    'linkaddress' => $subsubmenu->linkaddress,
                                    'target' => $subsubmenu->target,
                                    'viewtype' => $subsubmenu->viewtype,
                                    'type' => $subsubmenu->type,
                                    'parent_id' => $subsubmenu->parent_id,
                                    'menuorderid' => $subsubmenu->menuorderid,
                                ];
                            }
                        }
                        if (!empty($subsubmenus)) {
                            $submenu['submenu'] = $subsubmenus;
                            usort($submenu['submenu'], function ($a, $b) {
                                return $a['menuorderid'] - $b['menuorderid'];
                            });
                        }
                    }
                }
            }

            return response()->json($JsonmenuItems);
        }
        else
        {
            return response()->json(['message'=>'no records available'], 200);
        }
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
