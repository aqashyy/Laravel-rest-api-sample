<?php

namespace App\Http\Controllers;

use App\Models\MenuItem;
use Illuminate\Http\Request;

class MainController extends Controller
{
   public function RoutesContents()
   {

    $menuAlias  =   str_replace('/','',request()->getPathInfo());

    $menuContents    =   MenuItem::where('alias',$menuAlias)->first();

    $html = html_entity_decode($menuContents->pageitem->description);
    $html2 = htmlspecialchars_decode($menuContents->pageitem->description);
    dd($html2);
        return view('pages.main',['data' => $menuContents]);
   }
}
