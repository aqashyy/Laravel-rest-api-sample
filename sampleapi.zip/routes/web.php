<?php

use App\Http\Controllers\Api\MenuitemsController;
use App\Http\Controllers\MainController;
use App\Models\MenuItem;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('apitest',[MenuitemsController::class,'index']);

$menus  =   MenuItem::where('state', '1')->get();
foreach ($menus as $menu)
{

    // dd($menu->alias);
    Route::get($menu->alias, [MainController::class,'RoutesContents']);
}


